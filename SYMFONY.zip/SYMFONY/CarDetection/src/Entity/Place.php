<?php

namespace App\Entity;

use App\Repository\PlaceRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: PlaceRepository::class)]
class Place
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column]
    private ?int $place_id = null;

    #[ORM\Column]
    private ?bool $is_empty = null;

    #[ORM\Column]
    private ?int $total_place = null;

    #[ORM\Column]
    private ?int $Availabl_spot = null;

    #[ORM\Column]
    private ?int $full_spot = null;

    #[ORM\OneToMany(mappedBy: 'place', targetEntity: Users::class)]
    private Collection $utilisateur;

    #[ORM\OneToOne(inversedBy: 'place', cascade: ['persist', 'remove'])]
    #[ORM\JoinColumn(nullable: false)]
    private ?Image $image = null;

    #[ORM\OneToMany(mappedBy: 'place', targetEntity: Dossier::class)]
    private Collection $dossier;

    public function __construct()
    {
        $this->utilisateur = new ArrayCollection();
        $this->dossier = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getPlaceId(): ?int
    {
        return $this->place_id;
    }

    public function setPlaceId(int $place_id): self
    {
        $this->place_id = $place_id;

        return $this;
    }

    public function isIsEmpty(): ?bool
    {
        return $this->is_empty;
    }

    public function setIsEmpty(bool $is_empty): self
    {
        $this->is_empty = $is_empty;

        return $this;
    }

    public function getTotalPlace(): ?int
    {
        return $this->total_place;
    }

    public function setTotalPlace(int $total_place): self
    {
        $this->total_place = $total_place;

        return $this;
    }

    public function getAvailablSpot(): ?int
    {
        return $this->Availabl_spot;
    }

    public function setAvailablSpot(int $Availabl_spot): self
    {
        $this->Availabl_spot = $Availabl_spot;

        return $this;
    }

    public function getFullSpot(): ?int
    {
        return $this->full_spot;
    }

    public function setFullSpot(int $full_spot): self
    {
        $this->full_spot = $full_spot;

        return $this;
    }

    /**
     * @return Collection<int, Users>
     */
    public function getUtilisateur(): Collection
    {
        return $this->utilisateur;
    }

    public function addUtilisateur(Users $utilisateur): self
    {
        if (!$this->utilisateur->contains($utilisateur)) {
            $this->utilisateur->add($utilisateur);
            $utilisateur->setPlace($this);
        }

        return $this;
    }

    public function removeUtilisateur(Users $utilisateur): self
    {
        if ($this->utilisateur->removeElement($utilisateur)) {
            // set the owning side to null (unless already changed)
            if ($utilisateur->getPlace() === $this) {
                $utilisateur->setPlace(null);
            }
        }

        return $this;
    }

    public function getImage(): ?Image
    {
        return $this->image;
    }

    public function setImage(Image $image): self
    {
        $this->image = $image;

        return $this;
    }

    /**
     * @return Collection<int, Dossier>
     */
    public function getDossier(): Collection
    {
        return $this->dossier;
    }

    public function addDossier(Dossier $dossier): self
    {
        if (!$this->dossier->contains($dossier)) {
            $this->dossier->add($dossier);
            $dossier->setPlace($this);
        }

        return $this;
    }

    public function removeDossier(Dossier $dossier): self
    {
        if ($this->dossier->removeElement($dossier)) {
            // set the owning side to null (unless already changed)
            if ($dossier->getPlace() === $this) {
                $dossier->setPlace(null);
            }
        }

        return $this;
    }
}
